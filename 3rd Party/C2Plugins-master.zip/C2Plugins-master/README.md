[Document](http://c2rexplugins.weebly.com/)  
[Download all plugins](https://github.com/rexrainbow/C2Plugins/archive/master.zip)
